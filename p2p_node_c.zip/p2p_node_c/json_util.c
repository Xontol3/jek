/*
 * json_util.c — Minimal JSON builder & parser
 */
#include "json_util.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

/* ── Internal helpers ───────────────────────────────────── */

static void jb_append(JsonBuf *j, const char *s, size_t n) {
    if (j->err) return;
    if (j->len + n + 1 > j->cap) { j->err = 1; return; }
    memcpy(j->buf + j->len, s, n);
    j->len += n;
    j->buf[j->len] = '\0';
}

static void jb_append_str(JsonBuf *j, const char *s) {
    jb_append(j, s, strlen(s));
}

/* Escape and append a JSON string value (with quotes) */
static void jb_append_escaped(JsonBuf *j, const char *s) {
    if (j->err) return;
    jb_append(j, "\"", 1);
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"')       jb_append(j, "\\\"", 2);
        else if (c == '\\') jb_append(j, "\\\\", 2);
        else if (c == '\n') jb_append(j, "\\n",  2);
        else if (c == '\r') jb_append(j, "\\r",  2);
        else if (c == '\t') jb_append(j, "\\t",  2);
        else if (c < 0x20) {
            char esc[8];
            snprintf(esc, sizeof esc, "\\u%04x", c);
            jb_append_str(j, esc);
        } else {
            jb_append(j, (char*)&c, 1);
        }
    }
    jb_append(j, "\"", 1);
}

/* Track whether we need a comma before next element.
 * We use a simple heuristic: if last char is { or [ → no comma. */
static int jb_need_comma(JsonBuf *j) {
    if (j->len == 0) return 0;
    char last = j->buf[j->len - 1];
    return (last != '{' && last != '[' && last != ':');
}

static void jb_comma_if_needed(JsonBuf *j) {
    if (jb_need_comma(j)) jb_append(j, ",", 1);
}

/* ── Public API ─────────────────────────────────────────── */

void jb_init(JsonBuf *j, char *buf, size_t cap) {
    j->buf = buf;
    j->len = 0;
    j->cap = cap;
    j->err = 0;
    if (cap > 0) buf[0] = '\0';
}

void jb_obj_begin(JsonBuf *j) {
    jb_comma_if_needed(j);
    jb_append(j, "{", 1);
}

void jb_obj_end(JsonBuf *j) {
    jb_append(j, "}", 1);
}

void jb_arr_begin(JsonBuf *j) {
    jb_comma_if_needed(j);
    jb_append(j, "[", 1);
}

void jb_arr_end(JsonBuf *j) {
    jb_append(j, "]", 1);
}

void jb_key(JsonBuf *j, const char *key) {
    jb_comma_if_needed(j);
    jb_append_escaped(j, key);
    jb_append(j, ":", 1);
}

void jb_str(JsonBuf *j, const char *val) {
    jb_comma_if_needed(j);
    if (!val) { jb_null(j); return; }
    jb_append_escaped(j, val);
}

void jb_int(JsonBuf *j, long long val) {
    jb_comma_if_needed(j);
    char tmp[32];
    snprintf(tmp, sizeof tmp, "%lld", val);
    jb_append_str(j, tmp);
}

void jb_bool(JsonBuf *j, int val) {
    jb_comma_if_needed(j);
    jb_append_str(j, val ? "true" : "false");
}

void jb_null(JsonBuf *j) {
    jb_comma_if_needed(j);
    jb_append_str(j, "null");
}

void jb_raw(JsonBuf *j, const char *raw) {
    jb_comma_if_needed(j);
    if (!raw) { jb_null(j); return; }
    jb_append_str(j, raw);
}

void jb_kv_str(JsonBuf *j, const char *k, const char *v) {
    jb_key(j, k);
    jb_str(j, v);
}

void jb_kv_int(JsonBuf *j, const char *k, long long v) {
    jb_key(j, k);
    jb_int(j, v);
}

void jb_kv_bool(JsonBuf *j, const char *k, int v) {
    jb_key(j, k);
    jb_bool(j, v);
}

const char *jb_get(JsonBuf *j) { return j->buf; }
size_t      jb_len(JsonBuf *j) { return j->len; }

/* ── Parser ─────────────────────────────────────────────── */

/* Skip whitespace */
static const char *skip_ws(const char *p, const char *end) {
    while (p < end && isspace((unsigned char)*p)) p++;
    return p;
}

/* Skip a JSON value, return pointer past it */
static const char *skip_value(const char *p, const char *end);

static const char *skip_string(const char *p, const char *end) {
    /* p points at opening " */
    p++; /* skip " */
    while (p < end && *p != '"') {
        if (*p == '\\') p++; /* skip escaped char */
        p++;
    }
    if (p < end) p++; /* skip closing " */
    return p;
}

static const char *skip_value(const char *p, const char *end) {
    p = skip_ws(p, end);
    if (p >= end) return p;
    if (*p == '"') return skip_string(p, end);
    if (*p == '{') {
        p++;
        p = skip_ws(p, end);
        while (p < end && *p != '}') {
            p = skip_string(p, end); /* key */
            p = skip_ws(p, end);
            if (p < end && *p == ':') p++;
            p = skip_value(p, end);
            p = skip_ws(p, end);
            if (p < end && *p == ',') p++;
            p = skip_ws(p, end);
        }
        if (p < end) p++;
        return p;
    }
    if (*p == '[') {
        p++;
        p = skip_ws(p, end);
        while (p < end && *p != ']') {
            p = skip_value(p, end);
            p = skip_ws(p, end);
            if (p < end && *p == ',') p++;
            p = skip_ws(p, end);
        }
        if (p < end) p++;
        return p;
    }
    /* number, bool, null */
    while (p < end && *p != ',' && *p != '}' && *p != ']' &&
           !isspace((unsigned char)*p)) p++;
    return p;
}

/* Find key in top-level JSON object.
 * Returns pointer to start of value (after ':'), or NULL. */
static const char *find_key(const char *json, size_t jlen,
                             const char *key, size_t keylen,
                             const char **val_end_out) {
    const char *p   = json;
    const char *end = json + jlen;

    p = skip_ws(p, end);
    if (p >= end || *p != '{') return NULL;
    p++; /* skip { */

    while (p < end) {
        p = skip_ws(p, end);
        if (p >= end || *p == '}') break;

        /* Read key */
        if (*p != '"') break;
        const char *ks = p + 1;
        p = skip_string(p, end);
        const char *ke = p - 1; /* points at closing " */

        size_t klen = (size_t)(ke - ks);

        p = skip_ws(p, end);
        if (p >= end || *p != ':') break;
        p++;

        p = skip_ws(p, end);
        const char *vs = p;
        p = skip_value(p, end);
        const char *ve = p;

        if (klen == keylen && memcmp(ks, key, keylen) == 0) {
            if (val_end_out) *val_end_out = ve;
            return vs;
        }

        p = skip_ws(p, end);
        if (p < end && *p == ',') p++;
    }
    return NULL;
}

int json_get_str(const char *json, size_t jlen,
                 const char *key, char *out, size_t outlen) {
    const char *ve = NULL;
    const char *vs = find_key(json, jlen, key, strlen(key), &ve);
    if (!vs || *vs != '"') return 0;

    /* unescape into out */
    vs++; /* skip opening " */
    size_t i = 0;
    while (vs < ve && *vs != '"' && i + 1 < outlen) {
        if (*vs == '\\' && vs + 1 < ve) {
            vs++;
            switch (*vs) {
                case '"':  out[i++] = '"';  break;
                case '\\': out[i++] = '\\'; break;
                case 'n':  out[i++] = '\n'; break;
                case 'r':  out[i++] = '\r'; break;
                case 't':  out[i++] = '\t'; break;
                default:   out[i++] = *vs;  break;
            }
        } else {
            out[i++] = *vs;
        }
        vs++;
    }
    out[i] = '\0';
    return 1;
}

int json_get_int(const char *json, size_t jlen,
                 const char *key, long long *out) {
    const char *ve = NULL;
    const char *vs = find_key(json, jlen, key, strlen(key), &ve);
    if (!vs) return 0;
    vs = skip_ws(vs, ve);
    if (vs >= ve) return 0;
    char tmp[32];
    size_t n = (size_t)(ve - vs);
    if (n >= sizeof tmp) n = sizeof tmp - 1;
    memcpy(tmp, vs, n);
    tmp[n] = '\0';
    *out = atoll(tmp);
    return 1;
}

int json_get_bool(const char *json, size_t jlen,
                  const char *key, int *out) {
    const char *ve = NULL;
    const char *vs = find_key(json, jlen, key, strlen(key), &ve);
    if (!vs) return 0;
    vs = skip_ws(vs, ve);
    if (vs >= ve) return 0;
    if (strncmp(vs, "true", 4) == 0)  { *out = 1; return 1; }
    if (strncmp(vs, "false", 5) == 0) { *out = 0; return 1; }
    return 0;
}

int json_get_raw(const char *json, size_t jlen,
                 const char *key, const char **val_start, size_t *val_len) {
    const char *ve = NULL;
    const char *vs = find_key(json, jlen, key, strlen(key), &ve);
    if (!vs) return 0;
    *val_start = vs;
    *val_len   = (size_t)(ve - vs);
    return 1;
}
