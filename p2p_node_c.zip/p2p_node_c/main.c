/*
 * main.c — P2P Hybrid Node entry point
 *
 * Usage:
 *   p2p_node [options]
 *
 * Options:
 *   --port PORT          Listen port (default: 5032)
 *   --id   NODE_ID       Node ID (default: auto from /etc/machine-id)
 *   --ip   IP            Public IP (default: auto-detect)
 *   --master HOST:PORT   Master signaling server
 *   --mode DIRECT|REVERSE
 *   --methods PATH       Path to methods.json
 *   --max-peers N        Max connected peers (default: 400)
 *   --no-master          Disable master signaling
 *   --help
 */

#define _GNU_SOURCE
#include "p2p_node.h"
#include "sha256.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* ── Global node for signal handler ────────────────────── */
static P2PNode *g_node = NULL;

static void sig_handler(int sig) {
    (void)sig;
    if (g_node) {
        fprintf(stderr, "\n[MAIN] Signal received, shutting down...\n");
        p2p_node_shutdown(g_node);
        p2p_node_destroy(g_node);
        g_node = NULL;
    }
    _exit(0);
}

/* ── Generate stable node ID ─────────────────────────────── */
static void generate_node_id(char out[P2P_NODE_ID_LEN], int port) {
    /* Try /etc/machine-id first */
    FILE *f = fopen("/etc/machine-id", "r");
    if (!f) f = fopen("/var/lib/dbus/machine-id", "r");
    char machine_id[128] = {0};
    if (f) {
        fgets(machine_id, sizeof machine_id, f);
        fclose(f);
        /* strip newline */
        char *nl = strchr(machine_id, '\n');
        if (nl) *nl = '\0';
    }

    /* Combine machine_id + port */
    char seed[256];
    snprintf(seed, sizeof seed, "%s-%d", machine_id[0] ? machine_id : "unknown", port);
    char hex[65];
    sha256_hex(seed, strlen(seed), hex);
    strncpy(out, hex, 32);
    out[32] = '\0';
}

/* ── Attempt to get our public IP ─────────────────────────── */
static void get_local_ip(char out[P2P_IP_LEN]) {
    /* Try to find first non-loopback IPv4 */
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { strncpy(out, "127.0.0.1", P2P_IP_LEN-1); return; }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("8.8.8.8");
    addr.sin_port = htons(53);

    if (connect(fd, (struct sockaddr*)&addr, sizeof addr) == 0) {
        struct sockaddr_in local;
        socklen_t len = sizeof local;
        if (getsockname(fd, (struct sockaddr*)&local, &len) == 0) {
            inet_ntop(AF_INET, &local.sin_addr, out, P2P_IP_LEN);
            close(fd);
            return;
        }
    }
    close(fd);
    strncpy(out, "0.0.0.0", P2P_IP_LEN-1);
}

/* ── Parse HOST:PORT string ──────────────────────────────── */
static void parse_host_port(const char *hp, char host[P2P_IP_LEN], int *port) {
    strncpy(host, hp, P2P_IP_LEN-1);
    char *colon = strrchr(host, ':');
    if (colon) {
        *colon = '\0';
        *port  = atoi(colon + 1);
    }
}

/* ── Usage ───────────────────────────────────────────────── */
static void usage(const char *prog) {
    fprintf(stderr,
        "Usage: %s [options]\n"
        "  --port PORT          Listen port          (default: 5032)\n"
        "  --id   NODE_ID       Node ID              (default: auto)\n"
        "  --ip   IP            Public IP            (default: auto)\n"
        "  --master HOST:PORT   Master signaling     (default: disabled)\n"
        "  --mode DIRECT|REVERSE                     (default: DIRECT)\n"
        "  --methods PATH       methods.json path\n"
        "  --max-peers N        Max peers            (default: 400)\n"
        "  --no-master          Disable master signaling\n"
        "  --secret KEY         Shared secret for future crypto use\n"
        "  --help\n",
        prog);
}

/* ═══════════════════════════════════════════════════════════
 * main
 * ═══════════════════════════════════════════════════════════ */

int main(int argc, char **argv) {
    Config cfg;
    memset(&cfg, 0, sizeof cfg);

    /* Defaults */
    cfg.node_port                = 5032;
    cfg.node_mode                = NODE_MODE_DIRECT;
    cfg.max_peers                = P2P_MAX_PEERS;
    cfg.auto_connect             = 1;
    cfg.relay_fallback           = 1;
    cfg.heartbeat_interval       = P2P_HEARTBEAT_INTERVAL;
    cfg.conn_timeout             = P2P_CONN_TIMEOUT;
    cfg.max_conn_attempts        = P2P_MAX_CONN_ATTEMPTS;
    cfg.backoff_base             = P2P_BACKOFF_BASE;
    cfg.blacklist_duration       = P2P_BLACKLIST_DURATION;
    cfg.discovery_interval       = 60;
    cfg.cleanup_interval         = P2P_CLEANUP_INTERVAL;
    cfg.auto_connect_delay       = 10;
    cfg.reverse_reconnect_interval = 30;
    cfg.master_signaling_enabled  = 0;
    cfg.master_signaling_interval = 90;
    cfg.dht_enabled              = 0;
    strncpy(cfg.shared_secret, "narxz1337/0x/1x", sizeof cfg.shared_secret - 1);

    /* Parse env */
    const char *env_port   = getenv("PORT");
    const char *env_ip     = getenv("SERVER_IP");
    const char *env_id     = getenv("NODE_ID");
    const char *env_secret = getenv("SHARED_SECRET");
    const char *env_master = getenv("MASTER_URL");

    if (env_port)   cfg.node_port = atoi(env_port);
    if (env_ip)     strncpy(cfg.node_ip, env_ip, P2P_IP_LEN-1);
    if (env_id)     strncpy(cfg.node_id, env_id, P2P_NODE_ID_LEN-1);
    if (env_secret) strncpy(cfg.shared_secret, env_secret, sizeof cfg.shared_secret-1);
    if (env_master) {
        /* Parse http://host:port */
        const char *hp = env_master;
        if (strncmp(hp, "http://", 7) == 0) hp += 7;
        parse_host_port(hp, cfg.master_host, &cfg.master_port);
        cfg.master_signaling_enabled = 1;
    }

    /* Parse argv */
    char methods_path[512] = {0};
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            usage(argv[0]); return 0;
        } else if (strcmp(argv[i], "--port") == 0 && i+1 < argc) {
            cfg.node_port = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--id") == 0 && i+1 < argc) {
            strncpy(cfg.node_id, argv[++i], P2P_NODE_ID_LEN-1);
        } else if (strcmp(argv[i], "--ip") == 0 && i+1 < argc) {
            strncpy(cfg.node_ip, argv[++i], P2P_IP_LEN-1);
        } else if (strcmp(argv[i], "--master") == 0 && i+1 < argc) {
            parse_host_port(argv[++i], cfg.master_host, &cfg.master_port);
            cfg.master_signaling_enabled = 1;
        } else if (strcmp(argv[i], "--mode") == 0 && i+1 < argc) {
            i++;
            if (strcasecmp(argv[i], "REVERSE") == 0)
                cfg.node_mode = NODE_MODE_REVERSE;
            else
                cfg.node_mode = NODE_MODE_DIRECT;
        } else if (strcmp(argv[i], "--methods") == 0 && i+1 < argc) {
            strncpy(methods_path, argv[++i], sizeof methods_path-1);
        } else if (strcmp(argv[i], "--max-peers") == 0 && i+1 < argc) {
            cfg.max_peers = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--no-master") == 0) {
            cfg.master_signaling_enabled = 0;
        } else if (strcmp(argv[i], "--secret") == 0 && i+1 < argc) {
            strncpy(cfg.shared_secret, argv[++i], sizeof cfg.shared_secret-1);
        } else {
            fprintf(stderr, "[MAIN] Unknown option: %s\n", argv[i]);
            usage(argv[0]); return 1;
        }
    }

    /* Auto-fill node_id and IP */
    if (!cfg.node_id[0])
        generate_node_id(cfg.node_id, cfg.node_port);
    if (!cfg.node_ip[0])
        get_local_ip(cfg.node_ip);

    /* Print startup info */
    fprintf(stderr,
        "╔══════════════════════════════════════════╗\n"
        "║   P2P Hybrid Node (C) - Direct Mode      ║\n"
        "╚══════════════════════════════════════════╝\n"
        "  Node ID   : %.8s...\n"
        "  Node IP   : %s\n"
        "  Port      : %d\n"
        "  Mode      : %s\n"
        "  Max Peers : %d\n"
        "  Master    : %s%s%s\n",
        cfg.node_id,
        cfg.node_ip,
        cfg.node_port,
        cfg.node_mode == NODE_MODE_DIRECT ? "DIRECT" : "REVERSE",
        cfg.max_peers,
        cfg.master_signaling_enabled ? cfg.master_host : "(disabled)",
        cfg.master_signaling_enabled ? ":" : "",
        cfg.master_signaling_enabled ? "" : "");
    fprintf(stderr, "  Master Port: %d\n\n",
        cfg.master_signaling_enabled ? cfg.master_port : 0);

    /* Signals */
    signal(SIGINT,  sig_handler);
    signal(SIGTERM, sig_handler);
    signal(SIGPIPE, SIG_IGN);

    /* Create node */
    P2PNode *n = p2p_node_create(&cfg);
    if (!n) {
        fprintf(stderr, "[MAIN] Failed to create P2P node\n");
        return 1;
    }
    g_node = n;

    /* Load methods if specified */
    if (methods_path[0]) {
        int r = p2p_load_methods_json(n, methods_path);
        if (r < 0) fprintf(stderr, "[MAIN] Warning: failed to load methods from %s\n",
                           methods_path);
        else fprintf(stderr, "[MAIN] Loaded %d method(s)\n", r);
    }

    /* Start server */
    if (p2p_node_start(n) < 0) {
        fprintf(stderr, "[MAIN] Failed to start P2P server\n");
        p2p_node_destroy(n);
        return 1;
    }

    /* Run event loop (blocks) */
    p2p_node_run(n);

    p2p_node_destroy(n);
    return 0;
}
