/*
 * json_util.h — Minimal JSON builder & parser (no external deps)
 * Sufficient for P2P message framing.
 */
#ifndef JSON_UTIL_H
#define JSON_UTIL_H

#include <stddef.h>
#include <stdint.h>

/* ── Builder ─────────────────────────────────────────────── */
typedef struct {
    char  *buf;
    size_t len;
    size_t cap;
    int    err;
} JsonBuf;

void jb_init(JsonBuf *j, char *buf, size_t cap);
void jb_obj_begin(JsonBuf *j);
void jb_obj_end(JsonBuf *j);
void jb_arr_begin(JsonBuf *j);
void jb_arr_end(JsonBuf *j);
void jb_key(JsonBuf *j, const char *key);
void jb_str(JsonBuf *j, const char *val);
void jb_int(JsonBuf *j, long long val);
void jb_bool(JsonBuf *j, int val);
void jb_null(JsonBuf *j);
void jb_raw(JsonBuf *j, const char *raw);  /* embed pre-built JSON */
/* convenience: key+value pairs */
void jb_kv_str(JsonBuf *j, const char *k, const char *v);
void jb_kv_int(JsonBuf *j, const char *k, long long v);
void jb_kv_bool(JsonBuf *j, const char *k, int v);
const char *jb_get(JsonBuf *j);
size_t      jb_len(JsonBuf *j);

/* ── Parser helpers ─────────────────────────────────────── */
/* Extract string value for key from flat JSON object.
 * Returns 1 on success, 0 if key not found. */
int json_get_str(const char *json, size_t jlen,
                 const char *key, char *out, size_t outlen);
int json_get_int(const char *json, size_t jlen,
                 const char *key, long long *out);
int json_get_bool(const char *json, size_t jlen,
                  const char *key, int *out);

/* Return pointer+length of nested object/array value (raw JSON) */
int json_get_raw(const char *json, size_t jlen,
                 const char *key, const char **val_start, size_t *val_len);

#endif /* JSON_UTIL_H */
